class HomePage{

    //locators
    constructor(page){
        this.page=page
        this.menu="//img[@alt='menu']"
        this.signoutButton="//button[text()='Sign out']"

    }

    //methods
    async logOut(){
  
         await this.page.click(this.menu)
         await this.page.click(this.signoutButton)

    }
}

module.exports=HomePage;