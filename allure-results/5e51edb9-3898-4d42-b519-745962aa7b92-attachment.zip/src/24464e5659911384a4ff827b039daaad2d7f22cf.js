const { expect } = require('@playwright/test')

class loginPage{

    //locators
    constructor(page){
        this.page=page
        this.username = "//input[@name='email1']"
        this.password = "//input[@name='password1']"
        this.loginButton = "//button[text()='Sign in']" 
        this.header="//h2[text()='Sign In']"
    }

    //methods
    async loginToApplication(){       
        await this.page.fill(this.username,"amarkmdr1@gmail.com")
        await this.page.fill(this.password,"amar@1234")
        await this.page.click(this.loginButton)  
    }

    async verifySigninHeader(){
        await expect(this.page.locator(this.header)).toBeVisible()
    }

}
module.exports = loginPage;


