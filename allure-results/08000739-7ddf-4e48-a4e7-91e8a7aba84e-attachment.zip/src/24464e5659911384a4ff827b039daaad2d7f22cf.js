class loginPage{

    //locators
    constructor(page){

        this.page=page
        this.username = "//input[@name='email1']"
        this.password = "//input[@name='password1']"
        this.loginButton = "//button[text()='Sign in']" 
    }

    //methods
    async loginToApplication(){
       
        await this.page.fill(this.username,"amarkmdr1@gmail.com")
        await this.page.fill(this.password,"amar@1234")
        await this.page.click(this.loginButton)  
    }

}
module.exports = loginPage;


