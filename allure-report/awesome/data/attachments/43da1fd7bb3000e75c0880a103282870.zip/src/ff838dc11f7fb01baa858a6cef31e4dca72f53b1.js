
const{test,expect} = require('@playwright/test')
const loginPage = require('../pages/loginpage')



test('login to application using POM',async({page})=>{

await page.goto('https://freelance-learn-automation.vercel.app/login')

const loginPage= new loginPage(page)

await loginPage.loginToApplication()

})