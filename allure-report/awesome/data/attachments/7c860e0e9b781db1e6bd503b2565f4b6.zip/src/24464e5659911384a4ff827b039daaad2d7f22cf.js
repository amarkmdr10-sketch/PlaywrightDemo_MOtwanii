class loginPage{

    constructor(page){

        this.page=page
        this.username = "//input[@name='email1']"
        this.password = "//input[@name='password1']"
        this.loginButton = "//button[text()='Sign in']" 
    }

    async loginToApplication(){
       
        await this.page.fill(this.username,"admin@email.com")
        await this.page.fill(this.password,"admin@1234")
        await this.page.click(this.loginButton)  
    }

}
module.exports = loginPage;


